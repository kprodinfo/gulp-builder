# Простой сборщик на Gulp
1. Установить node.js
2. bower i
3. npm i
4. gulp
